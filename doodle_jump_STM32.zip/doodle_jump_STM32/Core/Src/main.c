/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "time.h"
#include "stdlib.h"
#include "LiquidCrystal.h"
#include "stdio.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef unsigned char byte;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
byte platform[] = {
  0x01,
  0x01,
  0x01,
  0x01,
  0x01,
  0x01,
  0x01,
  0x01
};

byte doodler[] = {
	0x00,
	0x00,
	0x1E,
	0x0E,
	0x0A,
	0x1E,
	0x04,
	0x00
};

byte bullet[] = {
	0x00,
	0x00,
	0x00,
	0x06,
	0x06,
	0x00,
	0x00,
	0x00
};

byte brokenPlatform[] = {
  0x01,
  0x01,
  0x01,
  0x00,
  0x00,
  0x01,
  0x01,
  0x01
};

byte blackHole[] = {
  0x00,
  0x04,
  0x0E,
  0x1F,
  0x1F,
  0x0E,
  0x04,
  0x00
};

byte enemy[] = {
  0x00,
  0x00,
  0x1F,
  0x05,
  0x1F,
  0x05,
  0x1F,
  0x00
};

byte spring[] = {
  0x00,
  0x00,
  0x09,
  0x15,
  0x15,
  0x13,
  0x00,
  0x00
};

int i =0;
int position = 0;
unsigned char data;
int hit_enemy = 0;
int blue_button_pressed = 0;
int buzzer_is_on = 0;
int gameOver = 0;
int fired = 0;
int score = 0;
int move_left = 0;
int move_right = 0;
int send_move_left = 0;
int send_move_right = 0;
int send_shoot = 0;
int player_x = 1;
int player_y = 2;
int falling = 0;
int jumping = 1;
int jump_charges = 7;
int distance = 5;
int sakhti = 9;
int random_for_sakhti = 0;
int random_for_sakhti1 = 0;
int board[21][4];
int random_for_platform = 0;
int random_for_broken_platform = 0;
int random_for_black_hole = 0;
int random_for_enemy = 0;
int random_creating_broken = 0;
int random_for_spring = 0;
int sevenSegDeg = 0;
int state = 0;

RTC_TimeTypeDef mytime;
RTC_DateTypeDef mydate;

unsigned char player_name[15] = "doodler";



void sevenSegWTimer(){
	if (sevenSegDeg != 3){
		sevenSegDeg++;
	}
	else{
		sevenSegDeg = 0;
	}

	int score_first_digit = score / 100;
	int score_second_digit = (score / 10) % 10;
	int score_third_digit = score % 10;

	if(sevenSegDeg == 0){
		 HAL_GPIO_WritePin(GPIOC,GPIO_PIN_6,0);
		 HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9,1);
		 numberToBcd(sakhti);
	}
	else if(sevenSegDeg == 1){
		 HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7,0);
		 HAL_GPIO_WritePin(GPIOC,GPIO_PIN_6|GPIO_PIN_8|GPIO_PIN_9,1);
		 numberToBcd(score_first_digit);
	}
	else if(sevenSegDeg == 2){
		 HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8,0);
		 HAL_GPIO_WritePin(GPIOC,GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_9,1);
		 numberToBcd(score_second_digit);
	}
	else{
		 HAL_GPIO_WritePin(GPIOC,GPIO_PIN_9,0);
		 HAL_GPIO_WritePin(GPIOC,GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8,1);
		 numberToBcd(score_third_digit);
	}

}

void numberToBcd(int i){
	int x1= i&1;
	int x2= i&2;
	int x3= i&4;
	int x4= i&8;
	if(x1>0) x1=1;
	if(x2>0) x2=1;
	if(x3>0) x3=1;
	if(x4>0) x4=1;
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_9,x4);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_8,x3);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,x2);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_4,x1);
}

//get and return RTC parameters


void random_generator(){
	random_for_platform = rand() % 4;
	random_for_broken_platform = rand() % 4;
	random_for_black_hole = rand() % 4;
	random_for_enemy = rand() % 4;

	random_for_sakhti = rand() % 100;
	random_for_sakhti1 = rand() % 100;
	random_creating_broken = rand() %100;
}

void start_game(){
	setCursor(1,0);
		write(0);
		board[1][0] = 1;
		setCursor(1,1);
		write(0);
		board[1][1] = 1;
		setCursor(1,2);
		write(0);
		board[1][2] = 1;
		setCursor(1,3);
		write(0);
		board[1][3] = 1;
		setCursor(6,1);
		write(0);
		board[6][1] = 1;
		setCursor(10,1);
		write(0);
		board[10][1] = 1;
		setCursor(15,0);
		write(0);
		board[15][0] = 1;
		setCursor(19,2);
		write(0);
		board[19][2] = 1;

		board[2][1] = 2;
		setCursor(2,1);
		write(1);
}

void update_board(){
	clear_player();

	distance++;
	random_generator();
	//creating platform
	if (random_for_sakhti > (60 + (3 * sakhti))){
		distance = 0;
		board[20][random_for_platform] = 1;
	}
	if (distance >= 6){
		distance = 0;
		board[20][random_for_platform] = 1;
	}

	//creating broken platform
	if(random_creating_broken > 90 && board[20][random_for_broken_platform] == 0){
		board[20][random_for_broken_platform] = 6;
	}

	//creating blackHole
	if(random_for_sakhti > 94 - (sakhti - 2) && board[20][random_for_black_hole] == 0 && board[19][random_for_black_hole] == 0){
		board[20][random_for_black_hole] = 9;
	}

	//creating enemy
	if(random_for_sakhti1 > 95 - (sakhti - 2) && board[20][random_for_enemy] == 0 && board[19][random_for_enemy] == 0){
		board[20][random_for_enemy] = 10;
	}

	//creating spring
	if(random_for_sakhti > 80){
		for (int j = 0 ; j < 4; j++){
			if (board[19][j] == 1 && board[20][j] == 0){
				board[20][j] = 11;
			}
		}
	}

	for (int i = 0; i < 20; i++){
		for (int j = 0; j < 4; j++){
			if(i == 0 && board[i][j] != 0){
				board[i][j] = 0;
				setCursor(i, j);
				print(" ");
			}
			//empty and platform
			if (board[i][j] == 0 && board [i+1][j] == 1){
				board[i][j] = 1;
				setCursor(i,j);
				write(0);
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
			//empty and broken platform
			else if (board[i][j] == 0 && board [i+1][j] == 6){
				board[i][j] = 6;
				setCursor(i,j);
				write(3);
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
			//empty and playerOnPlatform
			else if (board[i][j] == 0 && board [i+1][j] == 3){
				board[i][j] = 1;
				setCursor(i,j);
				write(0);
				board[i+1][j] = 2;
			}
			//empty and playerOnBrokenPlatform
			else if (board[i][j] == 0 && board [i+1][j] == 7){
				board[i][j] = 6;
				setCursor(i,j);
				write(3);
				board[i+1][j] = 2;
			}
			//empty and bulletOnPlatform
			else if (board[i][j] == 0 && board [i +1][j] == 5){
				board[i][j] = 1;
				setCursor(i,j);
				write(0);
				board[i+1][j] = 4;
			}
			//empty and bulletOnBrokenPlatform
			else if (board[i][j] == 0 && board [i + 1][j] == 8){
				board[i][j] = 6;
				setCursor(i,j);
				write(3);
				board[i+1][j] = 4;
			}
			//empty and blackHole
			else if (board[i][j] == 0 && board [i + 1][j] == 9){
				board[i][j] = 9;
				setCursor(i,j);
				write(4);
				board[i+1][j] = 0;
				setCursor(i+1, j);
				print(" ");
			}
			//empty and enemy
			else if(board[i][j] == 0 && board[i+1][j] == 10){
				board[i][j] = 10;
				setCursor(i,j);
				write(5);
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
			//platform and empty
			else if (board[i + 1][j] == 1 && board[i][j] == 0){
				board[i + 1][j] = 0;
				setCursor(i+1, j);
				print(" ");
				board[i][j] = 1;
				setCursor(i,j);
				write(0);
			}
			//broken platform and empty
			else if (board[i+1][j] == 6 && board[i][j] == 0){
				board[i + 1][j] = 0;
				setCursor(i+1, j);
				print(" ");
				board[i][j] = 6;
				setCursor(i,j);
				write(3);
			}
			//platform and player
			else if (board[i + 1][j] == 1 && board[i][j] == 2){
				board[i + 1][j] = 0;
				setCursor(i+1,j);
				print(" ");
				board[i][j] = 3;
			}
			//black hole and player or playerOnplatform or playerOnBrokenPlatform
			else if (board[i+1][j] == 9 && (board[i][j] == 2 || board[i][j] == 3 || board[i][j] == 7)){
				gameOver = 1;
				  position = 0;

				clearScreen();
			}
			//broken platform and player
			else if (board[i+1][j] == 6 && board[i][j] == 2){
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
				board[i][j] = 7;
			}
			//platform and bullet
			else if (board[i + 1][j] == 1 && board[i][j] == 4){
				board[i + 1][j] = 0;
				setCursor(i+1,j);
				print(" ");
				board[i][j] = 5;
			}
			//broken platform and bullet
			else if (board[i+1][j] == 6 && board[i][j] == 4){
				board[i + 1][j] = 0;
				setCursor(i+1,j);
				print(" ");
				board[i][j] = 8;
			}
			//blackHole and bullet
			else if(board [i+1][j] == 9 && board[i][j] == 4){
				board[i][j] = 9;
				setCursor(i,j);
				write(4);
				board[i+1][j] = 0;
				setCursor(i+1, j);
				print(" ");
			}
			//enemy and bullet
			else if(board[i+1][j] == 10 && board[i][j] == 4){
				board[i][j] = 0;
				setCursor(i,j);
				print(" ");
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
			//enemy and player or playerOnPlatform or playerOnBrokenPlatform
			else if(board[i+1][j] == 10 && (board[i][j] == 2 || board[i][j] == 3 || board[i][j] == 7)){
				hit_enemy = 1;
				jump_charges = 0;
			}
			//player and spring
			else if(board[i][j] == 2 && board[i+1][j] == 11){
				board[i][j] = 12;
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
			//bullet and spring
			else if(board[i][j] == 4 && board[i+1][j] == 11){
				board[i][j] = 13;
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
			//empty and spring
			else if(board[i][j] == 0 && board[i+1][j] == 11){
				board[i][j] = 11;
				setCursor(i,j);
				write(6);
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
			//empty and playerOnSpring
			else if(board[i][j] == 0 && board[i+1][j] == 12){
				board[i][j] = 11;
				setCursor(i,j);
				write(6);
				board[i+1][j] = 2;
			}
			//playerOnSpring and platform
			else if(board[i][j] == 12 && board[i+1][j] == 1){
				board[i][j] = 3;
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
			//playerOnSpring and brokenPlatform
			else if(board[i][j] == 12 && board[i+1][j] == 6){
				board[i][j] = 7;
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
			//bulletOnSpring and empty
			else if (board[i][j] == 13 && board[i+1][j] == 0){
				board[i][j] = 4;
			}
			//bulletOnSpring and platform
			else if(board[i][j] == 13 && board[i+1][j] == 1){
				board[i][j] = 5;
				board[i+1][j] = 0;
				setCursor(i+1, j);
				print(" ");
			}
			//bulletOnSpring and brokenPlatform
			else if(board[i][j] == 13 && board[i+1][j] == 6){
				board[i][j] = 8;
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
			}
		}
	}
}

void move_player_up(){
	clear_player();

	jump_charges -= 1;

	if(jump_charges == 0){
		buzzer_on_fall();
		buzzer_is_on = 1;
	}

	if (player_y < 10){

		for (int i = 20; i > 1; i--){
			for (int j = 0 ; j < 4; j++){
				//bullet and empty
				if (board[i][j] == 4 && board[i + 1][j] == 0){
					board[i][j] = 0;
					setCursor(i,j);
					print(" ");
					board[i+1][j] = 4;
					setCursor(i+1, j);
					write(2);
				}
				//bullet and platform
				else if(board[i][j] == 4 && board[i + 1][j] == 1){
					board[i][j] = 0;
					setCursor(i,j);
					print(" ");
					board[i+1][j] = 5;
					setCursor(i + 1, j);
					write(2);
				}
				//bullet and broken platform
				else if (board[i][j] == 4 && board[i+1][j] == 6){
					board[i][j] = 0;
					setCursor(i,j);
					print(" ");
					board[i+1][j] = 8;
					setCursor(i + 1, j);
					write(2);
				}
				//bulletOnPlatform and empty
				if(board[i][j] == 5 && board[i+1][j] == 0){
					board[i][j] = 1;
					setCursor(i,j);
					write(0);
					board[i+1][j] = 4;
					setCursor(i+1, j);
					write(2);
				}
				//bulletOnBrokenPlatform and empty
				else if (board[i][j] == 8 && board[i+1][j] == 0){
					board[i][j] = 6;
					setCursor(i,j);
					write(3);
					board[i+1][j] = 4;
					setCursor(i+1, j);
					write(2);
				}
				//bulletOnBrokenPlatform and platform
				else if (board[i][j] == 8 && board[i+1][j]){
					board[i][j] = 6;
					setCursor(i,j);
					write(3);
					board[i+1][j] = 5;
					setCursor(i+1, j);
					write(2);
				}
				//bulletOnPlatform and platform
				else if(board[i][j] == 5 && board[i+1][j] == 1){
					board[i][j] = 1;
					setCursor(i,j);
					write(0);
					board[i+1][j] = 5;
					setCursor(i +1, j);
					write(2);
				}
				//bulletOnPlatform and broken platform
				else if(board[i][j] == 5 && board[i+1][j] == 1){
					board[i][j] = 1;
					setCursor(i,j);
					write(0);
					board[i+1][j] = 8;
					setCursor(i +1, j);
					write(2);
				}
				//bulletOnbrokenPlatform and broken platform
				else if(board[i][j] == 8 && board[i+1][j] == 6){
					board[i][j] = 6;
					setCursor(i,j);
					write(3);
					board[i+1][j] = 8;
					setCursor(i +1, j);
					write(2);
				}
				//blackHole and bullet
				else if(board [i+1][j] == 9 && board[i][j] == 4){
					board[i][j] = 0;
					setCursor(i,j);
					print(" ");
				}
				//blackHole and bulletOnPlatform
				else if(board [i+1][j] == 9 && board[i][j] == 5){
					board[i][j] = 1;
					setCursor(i,j);
					write(0);
				}
				//blackHole and bulletOnBrokenPlatform
				else if(board [i+1][j] == 9 && board[i][j] == 8){
					board[i][j] = 6;
					setCursor(i,j);
					write(3);
				}
				//enemy and bullet
				else if(board [i+1][j] == 10 && board[i][j] == 4){
					board[i+1][j] = 0;
					setCursor(i+1,j);
					print(" ");
					board[i][j] = 0;
					setCursor(i,j);
					print(" ");
				}
				//enemy and bulletOnPlatform
				else if(board [i+1][j] == 10 && board[i][j] == 5){
					board[i+1][j] = 0;
					setCursor(i+1,j);
					print(" ");
					board[i][j] = 1;
					setCursor(i,j);
					write(0);
				}
				//enemy and bulletOnBrokenPlatform
				else if(board [i+1][j] == 10 && board[i][j] == 8){
					board[i+1][j] = 0;
					setCursor(i+1,j);
					print(" ");
					board[i][j] = 6;
					setCursor(i,j);
					write(3);
				}
				//bulletOnPlatform and spring
				else if (board[i][j] == 5 && board[i+1][j] == 11){
					board[i][j] = 1;
					setCursor(i,j);
					write(0);
					board[i+1][j] = 13;
					setCursor(i+1,j);
					write(2);
				}
				//bulletOnSpring and platform
				else if (board[i][j] == 13 && board[i+1][j] == 1){
					board[i][j] = 11;
					setCursor(i,j);
					write(6);
					board[i+1][j] = 5;
					setCursor(i+1,j);
					write(2);
				}
				//bulletOnSpring and brokenPlatform
				else if (board[i][j] == 13 && board[i+1][j] == 6){
					board[i][j] = 11;
					setCursor(i,j);
					write(6);
					board[i+1][j] = 8;
					setCursor(i+1,j);
					write(2);
				}
				//bulletOnSpring and empty
				else if (board[i][j] == 13 && board[i+1][j] == 1){
					board[i][j] = 11;
					setCursor(i,j);
					write(6);
					board[i+1][j] = 4;
					setCursor(i+1,j);
					write(2);
				}
			}
		}

		//platform above player
		if (board[player_y + 1][player_x] == 1 && board[player_y][player_x] == 2){
			board[player_y + 1][player_x] = 3;
			setCursor(player_y + 1, player_x);
			write(1);
			board[player_y][player_x] = 0;
			setCursor(player_y,player_x);
			print(" ");
		}
		//platform above playerOnPlatform
		else if(board[player_y + 1][player_x] == 1 && board[player_y][player_x] == 3)
		{
			board[player_y + 1][player_x] = 3;
			setCursor(player_y + 1, player_x);
			write(1);
			board[player_y][player_x] = 1;
			setCursor(player_y,player_x);
			write(0);
		}
		//platform above playerOnBrokenPlatform
		else if (board[player_y + 1][player_x] == 1 && board[player_y][player_x] == 7){
			board[player_y + 1][player_x] = 3;
			setCursor(player_y + 1, player_x);
			write(1);
			board[player_y][player_x] = 6;
			setCursor(player_y,player_x);
			write(3);
		}
		//empty above player
		else if(board[player_y + 1][player_x] == 0 && board[player_y][player_x] == 2){
			board[player_y + 1][player_x] = 2;
			setCursor(player_y + 1, player_x);
			write(1);
			board[player_y][player_x] = 0;
			setCursor(player_y, player_x);
			print(" ");
		}
		//empty above playerOnPlatform
		else if(board[player_y + 1][player_x] == 0 && board[player_y][player_x] == 3){
			board[player_y + 1][player_x] = 2;
			setCursor(player_y + 1, player_x);
			write(1);
			board[player_y][player_x] = 1;
			setCursor(player_y, player_x);
			write(0);
		}
		//empty above playerOnBrokenPlatform
		else if(board[player_y + 1][player_x] == 0 && board[player_y][player_x] == 7){
			board[player_y + 1][player_x] = 2;
			setCursor(player_y + 1, player_x);
			write(1);
			board[player_y][player_x] = 6;
			setCursor(player_y, player_x);
			write(3);
		}
		//brokenPlatform above player
		else if(board[player_y+1][player_x] == 6 && board[player_y][player_x] == 2){
			board[player_y + 1][player_x] = 7;
			setCursor(player_y + 1, player_x);
			write(1);
			board[player_y][player_x] = 0;
			setCursor(player_y, player_x);
			print(" ");
		}
		//brokenPlatform above playerOnPlatform
		else if (board[player_y+1][player_x] == 6 && board[player_y][player_x] == 3){
			board[player_y + 1][player_x] = 7;
			setCursor(player_y + 1, player_x);
			write(1);
			board[player_y][player_x] = 1;
			setCursor(player_y, player_x);
			write(1);
		}
		//broken platfrm above playerOnBrokenPlatform
		else if(board[player_y+1][player_x] == 6 && board[player_y][player_x] == 7){
			board[player_y + 1][player_x] = 7;
			setCursor(player_y + 1, player_x);
			write(1);
			board[player_y][player_x] = 6;
			setCursor(player_y, player_x);
			write(3);
		}
		//spring above playerOnPlatform
		else if (board[player_y][player_x] == 3 && board[player_y+1][player_x] == 11){
			board[player_y][player_x] = 1;
			setCursor(player_y,player_x);
			write(0);
			board[player_y+1][player_x] = 12;
			setCursor(player_y + 1,player_x);
			write(1);
		}
		//platform above playerOnSpring
		else if (board[player_y][player_x] == 12 && board[player_y+1][player_x] == 1){
			board[player_y][player_x] = 11;
			setCursor(player_y,player_x);
			write(6);
			board[player_y+1][player_x] = 3;
			setCursor(player_y+1,player_x);
			write(1);
		}

		//empty above playerOnSpring
		else if (board[player_y][player_x] == 12 && board[player_y+1][player_x] == 0){
			board[player_y][player_x] = 11;
			setCursor(player_y,player_x);
			write(6);
			board[player_y+1][player_x] = 2;
			setCursor(player_y+1,player_x);
			write(1);
		}

		//brokenPlatform above playerOnSpring
		else if (board[player_y][player_x] == 12 && board[player_y+1][player_x] == 6){
			board[player_y][player_x] = 11;
			setCursor(player_y,player_x);
			write(6);
			board[player_y+1][player_x] = 7;
			setCursor(player_y+1,player_x);
			write(1);
		}
		//blackHole above player or playerOnPlatform or playerOnBrokenPlatform
		else if(board[player_y + 1][player_x] == 9 && (board[player_y][player_x] == 2 || board[player_y][player_x] == 3 || board[player_y][player_x] == 7)){
			gameOver = 1;
			  position = 0;

			clearScreen();
		}
		//enemy above player or playerOnPlatform or playerOnBrokenPlatform
		else if(board[player_y + 1][player_x] == 10 && (board[player_y][player_x] == 2 || board[player_y][player_x] == 3 || board[player_y][player_x] == 7)){
			hit_enemy = 1;
			jump_charges = 0;
		}
		player_y += 1;
	}
	else if (player_y == 10){
		update_board();
		score += sakhti + 1;
	}
}

void move_player_down(){
	clear_player();

	for (int i = 20; i > 1; i--){
		for (int j = 0 ; j < 4; j++){
			//bullet and empty
			if (board[i][j] == 4 && board[i + 1][j] == 0){
				board[i][j] = 0;
				setCursor(i,j);
				print(" ");
				board[i+1][j] = 4;
				setCursor(i+1, j);
				write(2);
			}
			//bullet and platform
			if(board[i][j] == 4 && board[i + 1][j] == 1){
				board[i][j] = 0;
				setCursor(i,j);
				print(" ");
				board[i+1][j] = 5;
				setCursor(i + 1, j);
				write(2);
			}
			//bullet and broken platform
			if(board[i][j] == 4 && board [i+1][j] == 6){
				board[i][j] = 0;
				setCursor(i,j);
				print(" ");
				board[i+1][j] = 8;
				setCursor(i + 1, j);
				write(2);
			}
			//bulletOnPlatform and empty
			if(board[i][j] == 5 && board[i+1][j] == 0){
				board[i][j] = 1;
				setCursor(i,j);
				write(0);
				board[i+1][j] = 4;
				setCursor(i+1, j);
				write(2);
			}
			//bulletOnPlatform and platform
			else if(board[i][j] == 5 && board[i+1][j] == 1){
				board[i][j] = 1;
				setCursor(i,j);
				write(1);
				board[i+1][j] = 5;
				setCursor(i +1, j);
				write(2);
			}
			//bulletOnPlatform and broken platform
			else if(board[i][j] == 5 && board[i+1][j] == 6){
				board[i][j] = 1;
				setCursor(i,j);
				write(1);
				board[i+1][j] = 8;
				setCursor(i +1, j);
				write(2);
			}
			//bulletOnBrokenPlatform and empty
			else if(board[i][j] == 8 && board[i+1][j] == 0){
				board[i][j] = 6;
				setCursor(i,j);
				write(3);
				board[i+1][j] = 4;
				setCursor(i +1, j);
				write(2);
			}
			//bulletOnBrokenPlatform and platform
			else if(board[i][j] == 8 && board[i+1][j] == 1){
				board[i][j] = 6;
				setCursor(i,j);
				write(3);
				board[i+1][j] = 8;
				setCursor(i +1, j);
				write(2);
			}
			//bulletOnBrokenPlatform and broken platform
			else if(board[i][j] == 8 && board[i+1][j] == 6){
				board[i][j] = 6;
				setCursor(i,j);
				write(3);
				board[i+1][j] = 8;
				setCursor(i +1, j);
				write(2);
			}
			//blackHole and bullet
			else if(board [i+1][j] == 9 && board[i][j] == 4){
				board[i][j] = 0;
				setCursor(i,j);
				print(" ");
			}
			else if(board [i+1][j] == 9 && board[i][j] == 5){
				board[i][j] = 1;
				setCursor(i,j);
				write(0);
			}
			else if(board [i+1][j] == 9 && board[i][j] == 8){
				board[i][j] = 6;
				setCursor(i,j);
				write(3);
			}
			//enemy and bullet
			else if(board [i+1][j] == 10 && board[i][j] == 4){
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
				board[i][j] = 0;
				setCursor(i,j);
				print(" ");
			}
			//enemy and bulletOnPlatform
			else if(board [i+1][j] == 10 && board[i][j] == 5){
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
				board[i][j] = 1;
				setCursor(i,j);
				write(0);
			}
			//enemy and bulletOnBrokenPlatform
			else if(board [i+1][j] == 10 && board[i][j] == 8){
				board[i+1][j] = 0;
				setCursor(i+1,j);
				print(" ");
				board[i][j] = 6;
				setCursor(i,j);
				write(3);
			}
			//bulletOnPlatform and spring
			else if (board[i][j] == 5 && board[i+1][j] == 11){
				board[i][j] = 1;
				setCursor(i,j);
				write(0);
				board[i+1][j] = 13;
				setCursor(i+1,j);
				write(2);
			}
			//bulletOnSpring and platform
			else if (board[i][j] == 13 && board[i+1][j] == 1){
				board[i][j] = 11;
				setCursor(i,j);
				write(6);
				board[i+1][j] = 5;
				setCursor(i+1,j);
				write(2);
			}
			//bulletOnSpring and brokenPlatform
			else if (board[i][j] == 13 && board[i+1][j] == 6){
				board[i][j] = 11;
				setCursor(i,j);
				write(6);
				board[i+1][j] = 8;
				setCursor(i+1,j);
				write(2);
			}
			//bulletOnSpring and empty
			else if (board[i][j] == 13 && board[i+1][j] == 1){
				board[i][j] = 11;
				setCursor(i,j);
				write(6);
				board[i+1][j] = 4;
				setCursor(i+1,j);
				write(2);
			}
		}
	}
	if (player_y == 0){
		gameOver = 1;
		  position = 0;

		clearScreen();
	}

	if (hit_enemy == 0){
		if (board[player_y - 1][player_x] == 1 && board[player_y][player_x] == 12){
			jump_charges = 20;
			buzzer_on_jump();
			buzzer_is_on = 1;
			HAL_GPIO_WritePin(GPIOE, GPIO_PIN_13,1);
			move_player_up();
		}
		else if (board[player_y - 1][player_x] == 1 && board[player_y][player_x] != 12){
			jump_charges = 7;
			buzzer_on_jump();
			buzzer_is_on = 1;
			move_player_up();
		}
	}

	//platform under player and hit_enemy
	if (board[player_y -1 ][player_x] == 1 && board[player_y][player_x] == 2 && hit_enemy == 1){
		board[player_y -1 ][player_x] = 3;
		setCursor(player_y - 1,player_x);
		write(1);
		board[player_y][player_x] = 0;
		setCursor(player_y,player_x);
		print(" ");
		player_y -= 1;
	}

	//platform under playerOnPlatform and hit_enemy
	else if (board[player_y -1 ][player_x] == 1 && board[player_y][player_x] == 3 && hit_enemy == 1){
		board[player_y -1 ][player_x] = 3;
		setCursor(player_y - 1,player_x);
		write(1);
		board[player_y][player_x] = 1;
		setCursor(player_y,player_x);
		print(0);
		player_y -= 1;
	}

	//broken platform under player
	else if (board[player_y - 1][player_x] == 6 && board[player_y][player_x] == 2){
		board[player_y-1][player_x] = 2;
		setCursor(player_y -1, player_x);
		write(1);
		board[player_y][player_x] = 0;
		setCursor(player_y, player_x);
		print(" ");
		player_y -= 1;
	}
	//broken platform under playerOnPlatform
	else if (board[player_y - 1][player_x] == 6 && board[player_y][player_x] == 3){
		board[player_y-1][player_x] = 2;
		setCursor(player_y -1, player_x);
		write(1);
		board[player_y][player_x] = 1;
		setCursor(player_y, player_x);
		write(0);
		player_y -= 1;
	}
	//empty under player
	else if(board[player_y][player_x] == 2 && board[player_y - 1][player_x] == 0){
		board[player_y][player_x] = 0;
		setCursor(player_y, player_x);
		print(" ");
		board[player_y - 1][player_x] = 2;
		setCursor(player_y - 1, player_x);
		write(1);
		player_y -= 1;
	}
	//spring under player
	else if(board[player_y - 1][player_x] == 11 && board[player_y][player_x] == 2){
		board[player_y][player_x] = 0;
		setCursor(player_y,player_x);
		print(" ");
		board[player_y - 1][player_x] = 12;
		setCursor(player_y-1, player_x);
		write(1);
		player_y-= 1;
	}
	//spring under playerOnPlatform
	else if(board[player_y - 1][player_x] == 11 && board[player_y][player_x] == 3){
		board[player_y][player_x] = 1;
		setCursor(player_y,player_x);
		write(0);
		board[player_y - 1][player_x] = 12;
		setCursor(player_y-1, player_x);
		write(1);
		player_y-= 1;
	}
	//spring under playerOnBrokenPlatform
	else if(board[player_y - 1][player_x] == 11 && board[player_y][player_x] == 2){
		board[player_y][player_x] = 0;
		setCursor(player_y,player_x);
		print(" ");
		board[player_y - 1][player_x] = 12;
		setCursor(player_y-1, player_x);
		write(1);
		player_y-= 1;
	}
	//blackHole under player or playerOnPlatform or playerOnBrokenPlatform
	else if(board[player_y - 1][player_x] == 9 && (board[player_y][player_x] == 2 || board[player_y][player_x] == 3 || board[player_y][player_x] == 7)){
		gameOver = 1;
		  position = 0;

		clearScreen();
	}
	//enemy under player or playerOnPlatform or playerOnBrokenPlatform
	else if(board[player_y - 1][player_x] == 10 && (board[player_y][player_x] == 2 || board[player_y][player_x] == 3 || board[player_y][player_x] == 7)){
		hit_enemy = 1;
		jump_charges = 0;
	}
	//player on broken platform
	else if(board[player_y][player_x] == 7){
		board[player_y][player_x] = 0;
		setCursor(player_y, player_x);
		print(" ");
		board[player_y - 1][player_x] = 2;
		setCursor(player_y - 1, player_x);
		write(1);
		player_y -= 1;
	}
	//player on platform
	else if(board[player_y][player_x] == 3){
		board[player_y][player_x] = 1;
		setCursor(player_y, player_x);
		write(0);
		board[player_y - 1][player_x] = 2;
		setCursor(player_y - 1, player_x);
		write(1);
		player_y -= 1;
	}
}

void move_player_left(){
  //playerOnPlatform
  if (board[player_y][player_x] == 3){
	  board[player_y][player_x] = 1;
  }
  //playerOnBrokenPlatform
  else if (board[player_y][player_x] == 7){
	  board[player_y][player_x] = 6;
  }
  //playerOnSpring
  else if (board[player_y][player_x] == 12){
	  board[player_y][player_x] = 11;
  }
  //player
  else if(board[player_y][player_x] == 2){
	  board[player_y][player_x] = 0;
  }


  if (player_x == 0){
	  player_x = 3;
  }
  else{
	  player_x -= 1;
  }

  //platform
  if (board[player_y][player_x] == 1){
	  board[player_y][player_x] = 3;
  }
  //broken platform
  else if( board[player_y][player_x] == 6){
	  board[player_y][player_x] = 7;
  }
  //spring
  else if( board[player_y][player_x] == 11){
	  board[player_y][player_x] = 12;
  }
  //blackHole or enemy
  else if(board[player_y][player_x] == 9 || board[player_y][player_x] == 10){
	  gameOver = 1;
	  position = 0;

	  clearScreen();
  }
  //empty
  else if(board[player_y][player_x] == 0){
	  board[player_y][player_x] = 2;
  }
}

void move_player_right(){

	//playerOnPlatform
	if (board[player_y][player_x] == 3){
	  board[player_y][player_x] = 1;
	}
	//playerOnBrokenPlatform
	else if (board[player_y][player_x] == 7){
		board[player_y][player_x] = 6;
	}
	//playerOnSpring
	else if (board[player_y][player_x] == 12){
	  board[player_y][player_x] = 11;
	}
	//player
	else if(board[player_y][player_x] == 2){
	  board[player_y][player_x] = 0;
	}

	if (player_x == 3){
	  player_x = 0;
	}
	else{
	  player_x += 1;
	}
	//platform
	if (board[player_y][player_x] == 1){
	  board[player_y][player_x] = 3;
	}
	//broken platform
	else if(board[player_y][player_x] == 6){
		board[player_y][player_x] = 7;
	}
	//spring
	else if( board[player_y][player_x] == 11){
	  board[player_y][player_x] = 12;
	}
	//blackHole or enemy
	else if(board[player_y][player_x] == 9 || board[player_y][player_x] == 10){
	  gameOver = 1;
	  position = 0;

	  clearScreen();
	}
	//empty
	else if(board[player_y][player_x] == 0){
	  board[player_y][player_x] = 2;
	}
}

void clear_player(){
	for(int i =  (player_y - 1) ; i < (player_y + 1); i++){
		for(int j = 0; j < 4; j++){
			if (board[i][j] == 0){
				setCursor(i,j);
				print(" ");
			}
			else if(board[i][j] == 1){
				setCursor(i,j);
				write(0);
			}
			else if(board[i][j] == 2 || board[i][j] == 3 || board[i][j] == 7){
				setCursor(i,j);
				write(1);
			}
			else if(board[i][j] == 6){
				setCursor(i,j);
				write(3);
			}
		}
	}
}

void shoot(){
	if (board[player_y + 2][player_x] == 0){
		board[player_y + 2][player_x] = 4;
		setCursor(player_y+2, player_x);
		write(2);
	}
	else if(board[player_y + 2][player_x] == 1){
		board[player_y + 2][player_x] = 5;
		setCursor(player_y+2, player_x);
		write(2);
	}
	else if(board[player_y + 2][player_x] == 6){
		board[player_y + 2][player_x] = 7;
		setCursor(player_y+2, player_x);
		write(2);
	}
}

void check_bullet(){
	for (int j = 0 ; j < 4; j++){
		//clear bullet
		if (board[19][j] == 4){
			board[19][j] = 0;
			setCursor(19,j);
			print(" ");
		}
		//clear bullet on platform
		else if(board[19][j] == 5){
			board[19][j] = 1;
			setCursor(19,j);
			write(0);
		}
		//clear bullet on broken platform
		else if(board[19][j ] == 8){
			board[19][j] = 6;
			setCursor(19,j);
			write(3);
		}
	}
}

void clearScreen(){
	for (int i  = 0; i < 20; i++){
		for (int j = 0; j < 4; j++){
			board[i][j] = 0;
			setCursor(i,j);
			print(" ");

		}
	}

	end_screen();
}
void clearScreen2(){
	for (int i  = 0; i < 20; i++){
			for (int j = 0; j < 4; j++){
				board[i][j] = 0;
				setCursor(i,j);
				print(" ");
			}
		}
}

void game_preview(){
	setCursor(2, 0);
	print("the doodli doodle");
	setCursor(9, 2);
	write(0);
	setCursor(10,2);
	write(1);
	for(int i = 1; i < 4; i+=2){
		setCursor(12 , i);
		write(5);
		setCursor(7 , i);
		write(5);
	}
	setCursor(5 , 2);
	write(6);
	setCursor(4 , 2);
	write(0);
	setCursor(13 , 2);
	write(4);

}

void about_screen(){
	setCursor(0,0);
	print("Alireza Noorbakhsh");
	setCursor(0,1);
	print("Faridreza Momtazandi");
	setCursor(0,2);
	int current_year = get_time_year();
	int current_month = get_time_month();
	int current_date = get_time_date();
	unsigned char data3[100] = "";
	sprintf(data3,"date %2d %2d %2d",current_year, current_month, current_date);
	print(data3);


}



/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc2;

I2C_HandleTypeDef hi2c1;

RTC_HandleTypeDef hrtc;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart2;

PCD_HandleTypeDef hpcd_USB_FS;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_SPI1_Init(void);
static void MX_USB_PCD_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC2_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_RTC_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int get_time_hours(){
	HAL_RTC_GetTime(&hrtc,&mytime,RTC_FORMAT_BIN);
	return mytime.Hours;
}
int get_time_minutes(){
	HAL_RTC_GetTime(&hrtc,&mytime,RTC_FORMAT_BIN);
	return mytime.Minutes;
}
int get_time_seconds(){
	HAL_RTC_GetTime(&hrtc,&mytime,RTC_FORMAT_BIN);
	return mytime.Seconds;
}
int get_time_year(){
	HAL_RTC_GetDate(&hrtc,&mydate,RTC_FORMAT_BIN);
	return mydate.Year;
}
int get_time_month(){
	HAL_RTC_GetDate(&hrtc,&mydate,RTC_FORMAT_BIN);
	return mydate.Month;
}
int get_time_date(){
	HAL_RTC_GetDate(&hrtc,&mydate,RTC_FORMAT_BIN);
	return mydate.Date;
}


unsigned char buffer[15]="";
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	if(huart->Instance == USART2){
		if (position == 0){
			for (int i = 0 ; i <15 ; i++){
				player_name[i] = "";
			}
		}
		if (state == 3 || state == 6){
			if(data != 0x0D){
					player_name[position] = data;
					player_name[position+1] = '\0';
				  position++;
			}else if(data == 0x0D){
				  HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_12);
				  HAL_UART_Transmit(&huart2, player_name, sizeof(player_name), 1000);

						//check the buffer for specific string with string.h function
			}

			//copy your ISR code

			HAL_UART_Receive_IT(&huart2,&data,sizeof(data));
		}
	}



}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	srand(175);

	for (int i = 0 ; i < 21 ; i++){
		for (int j  = 0; j < 4; j++){
			board[i][j] = 0;
		}
	}

	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	GPIO_InitTypeDef temp;
	temp.Mode =GPIO_MODE_OUTPUT_PP;
	temp.Pin = (GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9);
	temp.Speed = GPIO_SPEED_FREQ_HIGH;
	temp.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOC, &temp);

	GPIO_InitTypeDef output;
	output.Mode =GPIO_MODE_OUTPUT_PP;
	output.Pin = (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_8|GPIO_PIN_9);
	output.Speed = GPIO_SPEED_FREQ_HIGH;
	output.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOB, &output);
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	LiquidCrystal(GPIOD, GPIO_PIN_1,GPIO_PIN_2,GPIO_PIN_3,GPIO_PIN_4,GPIO_PIN_5,GPIO_PIN_6,GPIO_PIN_7);
	begin(20,4);
	setCursor(0,0);
	createChar(0, platform);
	createChar(1, doodler);
	createChar(2, bullet);
	createChar(3, brokenPlatform);
	createChar(4, blackHole);
	createChar(5, enemy);
	createChar(6, spring);

	game_preview();


  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_SPI1_Init();
  MX_USB_PCD_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_ADC2_Init();
  MX_USART2_UART_Init();
  MX_RTC_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */

  mytime.Hours = 12;
  mytime.Minutes = 18;
  mytime.Seconds = 20;

  HAL_RTC_SetTime ( &hrtc, &mytime, RTC_FORMAT_BIN);

  mydate.Year = 22;
  mydate.Month = 6;
  mydate.Date = 27;

  HAL_RTC_SetDate ( &hrtc, &mydate, RTC_FORMAT_BIN);

  HAL_TIM_Base_Start_IT(&htim2);
  HAL_TIM_Base_Start_IT(&htim3);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);




//  HAL_UART_Receive_IT(&huart2,&data,sizeof(data));




  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI
                              |RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB|RCC_PERIPHCLK_USART2
                              |RCC_PERIPHCLK_I2C1|RCC_PERIPHCLK_RTC
                              |RCC_PERIPHCLK_TIM1|RCC_PERIPHCLK_ADC12;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.Adc12ClockSelection = RCC_ADC12PLLCLK_DIV1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  PeriphClkInit.USBClockSelection = RCC_USBCLKSOURCE_PLL;
  PeriphClkInit.Tim1ClockSelection = RCC_TIM1CLK_HCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{

  /* USER CODE BEGIN ADC2_Init 0 */

  /* USER CODE END ADC2_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC2_Init 1 */

  /* USER CODE END ADC2_Init 1 */
  /** Common config
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.SamplingTime = ADC_SAMPLETIME_601CYCLES_5;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x2000090E;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef sDate = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */
  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 39;
  hrtc.Init.SynchPrediv = 999;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */

  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
  sTime.Hours = 0x0;
  sTime.Minutes = 0x0;
  sTime.Seconds = 0x0;
  sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
  sTime.StoreOperation = RTC_STOREOPERATION_RESET;
  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  sDate.WeekDay = RTC_WEEKDAY_MONDAY;
  sDate.Month = RTC_MONTH_JANUARY;
  sDate.Date = 0x1;
  sDate.Year = 0x0;

  if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_4BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 72;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 100;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 119;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 2399;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 10000;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USB Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_PCD_Init(void)
{

  /* USER CODE BEGIN USB_Init 0 */

  /* USER CODE END USB_Init 0 */

  /* USER CODE BEGIN USB_Init 1 */

  /* USER CODE END USB_Init 1 */
  hpcd_USB_FS.Instance = USB;
  hpcd_USB_FS.Init.dev_endpoints = 8;
  hpcd_USB_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_FS.Init.battery_charging_enable = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_Init 2 */

  /* USER CODE END USB_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, CS_I2C_SPI_Pin|LD4_Pin|LD3_Pin|GPIO_PIN_10
                          |LD9_Pin|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11|GPIO_PIN_13|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pins : DRDY_Pin MEMS_INT3_Pin MEMS_INT4_Pin MEMS_INT2_Pin */
  GPIO_InitStruct.Pin = DRDY_Pin|MEMS_INT3_Pin|MEMS_INT4_Pin|MEMS_INT2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : CS_I2C_SPI_Pin LD4_Pin LD3_Pin PE10
                           LD9_Pin PE15 */
  GPIO_InitStruct.Pin = CS_I2C_SPI_Pin|LD4_Pin|LD3_Pin|GPIO_PIN_10
                          |LD9_Pin|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB11 PB13 PB15 */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_13|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD9 PD11 PD13 PD15 */
  GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_11|GPIO_PIN_13|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */

void buzzer_on_jump(){
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,50);
}

void buzzer_on_fall(){
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,50);

}

void buzzer_off(){
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1,0);
}

void start_blinking(){
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2,i);
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3,i);
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4,i);
}

void stop_blink(){
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2,0);
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3,0);
	  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4,0);
}

void send_uart(){
	char result_to_uart[30] = "";
	int n = sprintf(result_to_uart, "name: %s, score: %d", player_name, score);
	HAL_UART_Transmit(&huart2, result_to_uart, n, 1000);
}

void main_menu(){
	setCursor(1,0);
	print("1: start");
	setCursor(1,1);
	print("2: about");

	setCursor (1,3);
	print("enter name...");

	HAL_UART_Receive_IT(&huart2,&data,sizeof(data));


}

void end_screen(){
	setCursor(0,0);
	char score_string[15] = "";
	sprintf(score_string, "score: %d", score);
	print(score_string);

	setCursor(0,1);
	char player_name_string[20] = "";
	sprintf(player_name_string, "name: %s", player_name);
	print(player_name_string);

	send_uart();
	state = 6;
	HAL_UART_Receive_IT(&huart2,&data,sizeof(data));

}

// Input pull down rising edge trigger interrupt pins:
// Row1 PD3, Row2 PD5, Row3 PD7, Row4 PB4
GPIO_TypeDef *const Row_ports[] = {GPIOD, GPIOD, GPIOD, GPIOD};
const uint16_t Row_pins[] = {GPIO_PIN_15, GPIO_PIN_13, GPIO_PIN_11, GPIO_PIN_9};
// Output pins: Column1 PD4, Column2 PD6, Column3 PB3, Column4 PB5
GPIO_TypeDef *const Column_ports[] = {GPIOB, GPIOB, GPIOB, GPIOE};
const uint16_t Column_pins[] = {GPIO_PIN_15, GPIO_PIN_13, GPIO_PIN_11, GPIO_PIN_15};
volatile uint32_t last_gpio_exti;

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if (last_gpio_exti + 200 > HAL_GetTick()) // Simple button debouncing
  {
    return;
  }
  last_gpio_exti = HAL_GetTick();

  int8_t row_number = -1;
  int8_t column_number = -1;

  if (GPIO_Pin == GPIO_PIN_0)
  {
     blue_button_pressed = 1;
	  if(state == 0){
		  state++;
	  }

	  if(state == 6){
		  state = 1;
		  gameOver = 0;
		  score = 0;
		  player_x = 1;
		  player_y = 2;
		  jump_charges = 7;
		  distance = 5;
		  hit_enemy = 0;
	  }
	  if(state == 9){
		  state = 1;
	  }
    return;
  }

  for (uint8_t row = 0; row < 4; row++) // Loop through Rows
  {
    if (GPIO_Pin == Row_pins[row])
    {
      row_number = row;
    }
  }

  HAL_GPIO_WritePin(Column_ports[0], Column_pins[0], 0);
  HAL_GPIO_WritePin(Column_ports[1], Column_pins[1], 0);
  HAL_GPIO_WritePin(Column_ports[2], Column_pins[2], 0);
  HAL_GPIO_WritePin(Column_ports[3], Column_pins[3], 0);

  for (uint8_t col = 0; col < 4; col++) // Loop through Columns
  {
    HAL_GPIO_WritePin(Column_ports[col], Column_pins[col], 1);
    if (HAL_GPIO_ReadPin(Row_ports[row_number], Row_pins[row_number]))
    {
      column_number = col;
    }
    HAL_GPIO_WritePin(Column_ports[col], Column_pins[col], 0);
  }

  HAL_GPIO_WritePin(Column_ports[0], Column_pins[0], 1);
  HAL_GPIO_WritePin(Column_ports[1], Column_pins[1], 1);
  HAL_GPIO_WritePin(Column_ports[2], Column_pins[2], 1);
  HAL_GPIO_WritePin(Column_ports[3], Column_pins[3], 1);

  if (row_number == -1 || column_number == -1)
  {
    return; // Reject invalid scan
  }
  //   C0   C1   C2   C3
  // +----+----+----+----+
  // | 1  | 2  | 3  | 4  |  R0
  // +----+----+----+----+
  // | 5  | 6  | 7  | 8  |  R1
  // +----+----+----+----+
  // | 9  | 10 | 11 | 12 |  R2
  // +----+----+----+----+
  // | 13 | 14 | 15 | 16 |  R3
  // +----+----+----+----+
  const uint8_t button_number = row_number * 4 + column_number + 1;
  switch (button_number)
  {
  case 1:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);
	  if(state == 3){
		  int seed = get_time_seconds();
		  srand(seed * 11);

		  state = 4;
	  }
    break;
  case 2:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);
	  if(state == 3){
		  state = 7;
	  }
    break;
  case 3:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 4:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 5:
    /* code */
	  move_left = 1;

	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 6:
    /* code */
	  fired = 1;

	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 7:
    /* code */
	  move_right = 1;

	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 8:
	/* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 9:
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 10:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 11:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 12:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 13:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

	break;
  case 14:
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 15:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;
  case 16:
    /* code */
	  HAL_GPIO_TogglePin(GPIOE,GPIO_PIN_8);

    break;

  default:
    break;
  }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
